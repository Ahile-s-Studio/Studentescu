using Studentescu.Models;

namespace Studentescu.ViewModels;

public class UsersViewModel
{
    public List<ApplicationUser> Users;
}