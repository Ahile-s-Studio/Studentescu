using Studentescu.Models;

namespace Studentescu.ViewModels;

public class NotificationsViewModel
{
    public List<Notification> Notifications { get; set; }
}